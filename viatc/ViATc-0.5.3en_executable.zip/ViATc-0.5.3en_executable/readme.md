ViATc
=====

ViATc - Vim mode at Total Commander  

This is an old version. Find newer ones at https://magicstep.github.io/viatc

About
=====

- efficient use of keyboard, lot's of quick shortcuts
- efficient use of software, use more functionality
- supports all that Autohotkey does, not just TotalCommander
- in fact, in addition to Vim style, Emacs or any style can also be programmed-in

Usage:
=====

- Put the ini file in your Total Commander directory "c:\Program Files\totalcmd" or "c:\Program Files (x86)\totalcmd"  
- Run the exe file. Notice: I promise that this exe is clean, but compiled AHK scripts trigger antiviruses so you might have to add an exception.
- Look for a new icon in the tray, right-click on it and choose Help.


Settings
========

You can add and remove shortcuts directly in the ini file or via ViATc Settings window (you must click Save before clicking Ok).
In the ini file lines that begin with a semicolon ; are ignored. It's a standard comment in ini files.  
If you have mapped CapsLock as Escape in other AHK script you need to map it again in viatc.ini like below
<CapsLock>=<Esc>


Author
======
- Author of the original Chinese version is linxinhong https://github.com/linxinhong
- Translator and maintainer of the English version is magicstep https://github.com/magicstep  
  contact me there or with the same nickname @gmail.com 
