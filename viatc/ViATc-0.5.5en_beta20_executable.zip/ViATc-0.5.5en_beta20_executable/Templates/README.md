Templates
=========
To add a template: 
1. Put a TC line-cursor on a file that will be duplicated
2. Press a then n  - this will invoke <CreateNewFile> menu
3. From the menu select "Add to new template (X)"
   The file will be copied into Templates folder in ViATc

To use a template:
1. Invoke <CreateNewFile> menu by pressing a then n  
2. Chose a template from the list, it will be used to create
   a new file in the current folder location
3. Rename if needed


The settings for templates are in the viatc.ini file at the bottom under [TemplateList]
The name of TemplateList in older versions was ShellNew




